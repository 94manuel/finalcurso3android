package com.example.manuelfernando.finalcurso3;

import android.content.Intent;
import android.graphics.Color;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void olvide(View view){
        Snackbar snackbar= Snackbar.make(view,"Debes recuperar tu cuenta",Snackbar.LENGTH_LONG)
                .setAction("RECUPERAR", new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        Toast.makeText(MainActivity.this,"Se ha enviado la informacion de recuperacion de la cuenta", Toast.LENGTH_LONG).show();
                    }
                });
        snackbar.setActionTextColor(Color.GREEN);
        View snackBarView = snackbar.getView();
        snackBarView.setBackgroundColor(Color.BLUE);
        snackbar.show();

    }
    public void iniciar(View view){
        Intent intent = new Intent(MainActivity.this,Galeria.class);
        EditText Texto = (EditText) findViewById(R.id.editText);
        EditText Texto2 = (EditText) findViewById(R.id.editText2);
        if (Texto.getText().toString().equals("") && Texto2.getText().toString().equals("")){
            Toast.makeText(MainActivity.this,"Debes ingresar ambos datos de usuario", Toast.LENGTH_LONG).show();
        }else{
            startActivity(intent);
        }
    }
    @Override
    protected void onStart() {
        super.onStart();
        Log.wtf("Ciclo de vida", "onStart");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.wtf("Ciclo de vida", "onRestart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.wtf("Ciclo de vida", "onResume");
    }
    @Override
    protected void onPause() {
        super.onPause();
        Log.wtf("Ciclo de vida", "onPause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.wtf("Ciclo de vida", "onStop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.wtf("Ciclo de vida", "onDestroy");
    }
}
